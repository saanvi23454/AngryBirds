<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="cactus" tilewidth="64" tileheight="64" spacing="2" margin="1" tilecount="1" columns="1">
 <image source="cactus.png" width="70" height="70"/>
</tileset>
