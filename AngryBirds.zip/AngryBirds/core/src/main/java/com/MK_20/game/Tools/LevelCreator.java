package com.MK_20.game.Tools;

import com.MK_20.game.AngryBirds;
import com.MK_20.game.Sprites.Glass;
import com.MK_20.game.Sprites.Wood;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.*;

import java.util.ArrayList;

public class LevelCreator {
    public ArrayList<Wood> woods;
    public ArrayList<Glass> glass;

    public LevelCreator(World world, TiledMap tiledmap) {
        //Will be changed.

        woods = new ArrayList<>();
        glass = new ArrayList<>();
        BodyDef bodyDef = new BodyDef();
        PolygonShape shape = new PolygonShape();
        FixtureDef fixtureDef = new FixtureDef();
        Body body;

        //ground body
        for (MapObject object: tiledmap.getLayers().get(2).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rectangle = ((RectangleMapObject) object).getRectangle();
            bodyDef.type = BodyDef.BodyType.StaticBody;
            bodyDef.position.set((rectangle.getX()+(rectangle.getWidth()/2))/ AngryBirds.PPM, (rectangle.getY()+(rectangle.getHeight()/2))/ AngryBirds.PPM);

            body = world.createBody(bodyDef);
            shape.setAsBox(rectangle.getWidth()/2/ AngryBirds.PPM, rectangle.getHeight()/2/ AngryBirds.PPM);
            fixtureDef.shape = shape;
            body.createFixture(fixtureDef);
        }

        //wood body
        for (MapObject object: tiledmap.getLayers().get(3).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rectangle = ((RectangleMapObject) object).getRectangle();
            woods.add(new Wood(world,tiledmap,rectangle));
        }

//        for (MapObject object: tiledmap.getLayers().get(4).getObjects().getByType(RectangleMapObject.class)) {
//            Rectangle rectangle = ((RectangleMapObject) object).getRectangle();
//            glass.add(new Glass(world, tiledmap, rectangle));
//        }
    }

    public ArrayList<Wood> getWoods() {
        return woods;
    }
}
