package com.MK_20.game.Sprites;

import com.MK_20.game.AngryBirds;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.*;

public class Wood extends InteractiveTileObject{

    private Sprite sprite;

    public Wood(World world, TiledMap tiledMap, Rectangle bounds) {
        super(world, tiledMap, bounds);
        this.sprite = new Sprite(new Texture("glassbox.png"));  // Example texture file

        // Set the size of the sprite to match the physical body
        sprite.setSize(bounds.getWidth() / AngryBirds.PPM, bounds.getHeight() / AngryBirds.PPM);

        // Set the position of the sprite to match the physics body
        sprite.setPosition(bounds.getX() / AngryBirds.PPM, bounds.getY() / AngryBirds.PPM);
        BodyDef bodyDef = new BodyDef();
        FixtureDef fixtureDef = new FixtureDef();
        PolygonShape shape = new PolygonShape();

        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set((bounds.getX()+(bounds.getWidth()/2)) / AngryBirds.PPM, (bounds.getY()+(bounds.getHeight()/2)) / AngryBirds.PPM);

        body = world.createBody(bodyDef);
        shape.setAsBox(bounds.getWidth()/2 / AngryBirds.PPM, bounds.getHeight()/2 / AngryBirds.PPM);
        fixtureDef.shape = shape;
        body.createFixture(fixtureDef);
    }

    public void update() {
        // Update the sprite's position based on the body's position
        sprite.setPosition(body.getPosition().x-sprite.getWidth()/2, body.getPosition().y-sprite.getHeight()/2);
    }

    public void draw(SpriteBatch batch) {
        sprite.draw(batch);
    }
}
