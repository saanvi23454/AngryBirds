package com.MK_20.game.Sprites;

import com.MK_20.game.AngryBirds;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;

import java.util.ArrayList;

public class Slingshot extends Sprite {
    public World world;
    public Body body;
    ShapeRenderer shapeRenderer;
    private Vector2 base;
    private Vector2 dragPosition;
    public static boolean dragging;
    public Vector2 top;

    public Slingshot(World world, float x, float y) {
        super(new Texture("sling.png"));
        this.world = world;
        this.base = new Vector2(x, y);
        this.top = new Vector2(x+60, y+100);
        setPosition(x, y);
        setSize(50,90);
        defineSlingshot();
        dragPosition = new Vector2(base);
        dragging = false;
        shapeRenderer = new ShapeRenderer();
    }

    public void defineSlingshot() {
        BodyDef bodyDef = new BodyDef();
        bodyDef.position.set(128 / AngryBirds.PPM, 128 / AngryBirds.PPM);
        bodyDef.type = BodyDef.BodyType.StaticBody;
        body = world.createBody(bodyDef);
//
//        FixtureDef fixtureDef = new FixtureDef();
//        CircleShape circleShape = new CircleShape();
//        circleShape.setRadius(10 / AngryBirds.PPM);
//        fixtureDef.shape = circleShape;
//        body.createFixture(fixtureDef);
    }

    public void startDrag(float x, float y) {
        dragging = true;
        dragPosition.set(x, y);
    }

    public void renderTrajectory(Camera camera) {
        if (!this.dragging) {
            return;
        }
        float startX=top.x-270, startY=top.y-25;

        Vector2 velocity=launchVelocity();
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        for (float t = 0; t < 5f; t += 0.1f) {
            float x = startX + velocity.x * t;
            float y = startY + velocity.y * t + 0.5f * -9.8f * t * t;

            if (y < 0) break;
            shapeRenderer.circle(x, y, 2f);
        }
        shapeRenderer.end();
    }

    public void updateDrag(float x, float y) {
        if (dragging) {
            dragPosition.set(x, y);
            //Gdx.app.log("Slingshot", "Dragging at: " + x + ", " + y);
        }
    }

    public void release() {
        dragging = false;
        dragPosition.set(base.x,base.y);
    }

    public Vector2 launchVelocity() {
        Vector2 direction = top.cpy().sub(dragPosition);
        direction.y *= (-1.5f);
        return direction.scl(1f);
    }

    public void dispose() {
        if (body != null && body.getWorld() != null) {
            world.destroyBody(body);
        }
    }
}
