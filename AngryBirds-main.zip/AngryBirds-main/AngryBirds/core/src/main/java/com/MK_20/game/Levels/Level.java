package com.MK_20.game.Levels;

import com.MK_20.game.AngryBirds;
import com.MK_20.game.Screens.PlayScreen;
import com.MK_20.game.Sprites.*;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Timer;

public abstract class Level {
    public static Level currentLevel;
    public ArrayList<Pig> pigs;
    public ArrayList<Bird> birds;
    public ArrayList<Box> boxes;
    public Slingshot slingshot;
    public Bird currentBird;

    public int currentPigs=0, currentBirds=0;
    public boolean nextBird = false;

    public Level() {
        pigs = new ArrayList<>();
        birds = new ArrayList<>();
        boxes = new ArrayList<>();
    }

    public void handleInput(float x, float y, boolean dragging, boolean released, ShapeRenderer shapeRenderer) {
        if (dragging) {
            Gdx.app.log("Input", "Dragging");
            slingshot.startDrag(x,y);
            slingshot.updateDrag(x, y, shapeRenderer);
        } else if (released) {
            Vector2 velocity = slingshot.launchVelocity();
            releaseBird(velocity);
            slingshot.release();
        }
    }

    public void releaseBird(Vector2 velocity) {
        if (currentBird != null) {
            Gdx.app.log("Release", "Bird velocity: " + velocity);
            currentBird.body.setType(BodyDef.BodyType.DynamicBody);
            currentBird.body.setLinearVelocity(velocity);
            currentBird.body.setLinearVelocity(currentBird.body.getLinearVelocity().scl(5));
            currentBird = null; //modify to make it the next bird

        }
    }

    public void update(float delta) {
        for (Pig pig : pigs) pig.update(delta);
        for (Bird bird : birds) bird.update(delta);
        for (Box box : boxes) box.update(delta);
        slingshot.update(delta);
        if (currentPigs == 0){
            Timer.schedule(new Timer.Task() {
                @Override
                public void run() {
                    // change to win screen after 4 sec
                    AngryBirds.game.setScreen(AngryBirds.game.won);
                }
                }, 2.0f);
        }
        if (currentBirds == 0){
            AngryBirds.game.setScreen(AngryBirds.game.failed);
        }
//        if (nextBird){
//            birds.remove(0);
//            currentBird = birds.get(0);
//            currentBird.body.setType(BodyDef.BodyType.StaticBody);
//            currentBird.setPosition(360f, 160f);
//        }
    }

    public void drawAll(SpriteBatch batch, ShapeRenderer shapeRenderer) {
        batch.begin();
        slingshot.draw(batch);
        for (Pig pig : pigs) {
            if (!pig.isDestroyed){
                pig.draw(batch);
            }
        }
        for (Bird bird : birds) {
            if (!bird.isDestroyed){
                bird.draw(batch);
            }
        }
        for (Box box : boxes) {
            if (!box.isDestroyed){
                box.draw(batch);
            }
        }
        batch.end();
        slingshot.renderTrajectory();
    }
}
