package com.MK_20.game.Levels;

import com.MK_20.game.Sprites.*;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.World;

public class Level3 extends Level {

    public Pig pig1;
    public RedBird rb1, rb2, rb3, rb4;
    public Box box1, box2, box3;
    public Box log1, log2, log3;

    public Level3(World world) {
        slingshot = new Slingshot(world, 330.0f, 85.0f);

        rb1 = new RedBird(world, 360f, 160f, 24, 24, 11);
        rb1.body.setType(BodyDef.BodyType.StaticBody);
        rb2 = new RedBird(world, 320f, 90f, 24, 24, 11);
        rb3 = new RedBird(world, 310f, 90f, 24, 24, 11);
        rb4 = new RedBird(world, 300f, 90f, 24, 24, 11);

        birds.add(rb1); currentBirds += 1;
        birds.add(rb2); currentBirds += 1;
        birds.add(rb3); currentBirds += 1;
        birds.add(rb4); currentBirds += 1;
        currentBird = rb1;

        box1 = new GlassBox(world, 880f, 80f, 40, 40);
        box2 = new GlassBox(world, 940f, 80f, 40, 40);
        box3 = new GlassBox(world, 1000f, 80f, 40, 40);

        log1 = new GlassBox(world, 905f, 130f, 40, 40);
        log2 = new GlassBox(world, 975f, 130f, 40, 40);

        log3 = new GlassBox(world, 940f, 170f, 40, 40);

        boxes.add(box1);
        boxes.add(box2);
        boxes.add(box3);
        boxes.add(log1);
        boxes.add(log2);
        boxes.add(log3);

        pig1 = new Pig(world, 940f, 130f, 24, 24, 12);
        pigs.add(pig1); currentPigs += 1;
    }
}
