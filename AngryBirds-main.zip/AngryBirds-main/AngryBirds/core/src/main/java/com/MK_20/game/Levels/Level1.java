package com.MK_20.game.Levels;

import com.MK_20.game.Sprites.*;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.World;

public class Level1 extends Level {

    public Pig pig;
    public RedBird rb1, rb2, rb3, rb4;
    public Box log1, log2, log3;

    public Level1(World world) {
        // Initialize slingshot
        slingshot = new Slingshot(world, 330.0f, 85.0f);


        // Initialize birds
        rb1 = new RedBird(world, 360f, 160f, 24, 24, 11);
        rb1.body.setType(BodyDef.BodyType.StaticBody);
        rb2 = new RedBird(world, 320f, 90f, 24, 24, 11);
        rb3 = new RedBird(world, 310f, 90f, 24, 24, 11);
        rb4 = new RedBird(world, 300f, 90f, 24, 24, 11);
        birds.add(rb1); currentBirds += 1;
        birds.add(rb2); currentBirds += 1;
        birds.add(rb3); currentBirds += 1;
        birds.add(rb4); currentBirds += 1;
        currentBird = rb1;


        // Structure with vertical and horizontal wood
        log1 = new WoodLogVertical(world, 900f, 100f, 10, 80);  // Left vertical wood
        log2 = new WoodLogVertical(world, 950f, 100f, 10, 80); // Right vertical wood
        log3 = new WoodLogHorizontal(world, 925f, 140f, 80, 10); // Top horizontal wood
        //horizontalWoodBottom = new WoodLogHorizontal(world, 925f, 60f, 80, 20); // Bottom horizontal wood

        boxes.add(log1);
        boxes.add(log2);
        boxes.add(log3);
        //boxes.add(horizontalWoodBottom);

        // Pig inside the structure
        pig = new Pig(world, 925f, 100f, 24, 24, 12);  // Positioned in the middle
        pigs.add(pig); currentPigs += 1;
    }
}
