package com.MK_20.game.Tools;

import com.MK_20.game.AngryBirds;
import com.MK_20.game.Screens.PlayScreen;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;

public class TrajectoryRenderer {

    private ShapeRenderer shapeRenderer;

    public TrajectoryRenderer() {
        shapeRenderer = new ShapeRenderer();
    }

    public void renderTrajectory(float startX, float startY, Vector2 velocity, float gravity, float timeStep, float maxTime) {
//        Gdx.app.log("Trajectory", "Start: (" + startX + ", " + startY + ")");
//        Gdx.app.log("Trajectory", "Velocity: (" + velocity.x + ", " + velocity.y + ")");

        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        for (float t = 0; t < maxTime; t += timeStep) {
            float x = startX + velocity.x * t;
            float y = startY + velocity.y * t + 0.5f * gravity * t * t;

            if (y < 0) break;
            shapeRenderer.circle(x, y, 2f);
        }
        shapeRenderer.end();
    }

    public void dispose() {
        shapeRenderer.dispose();
    }
}
