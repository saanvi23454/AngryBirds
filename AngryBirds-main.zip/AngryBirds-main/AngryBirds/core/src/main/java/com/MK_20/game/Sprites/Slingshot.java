package com.MK_20.game.Sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.MK_20.game.Tools.TrajectoryRenderer;

public class Slingshot extends Sprite {
    public World world;
    public Body body;
    private final Vector2 base;
    private Vector2 dragPosition;
    public static boolean dragging;
    private Vector2 top;

    private TrajectoryRenderer trajectoryRenderer;

    public Slingshot(World world, float x, float y) {
        super(new Texture("sling.png"));
        this.world = world;
        base = new Vector2(x, y);
        setPosition(x, y);
        setSize(50 , 90 );
        top = new Vector2(x+60,y+100);
        defineSlingshot();
        dragPosition = new Vector2(base);
        dragging = false;
        world.setGravity(new Vector2(0, -9.8f));
        this.trajectoryRenderer = new TrajectoryRenderer();
    }

    private void defineSlingshot() {
        BodyDef bodyDef = new BodyDef();
        bodyDef.position.set(base);
        bodyDef.type = BodyDef.BodyType.StaticBody;
        body = world.createBody(bodyDef);
    }

    public void draw(SpriteBatch batch) {
        //Gdx.app.log("Slingshot", "Drawing slingshot at: " + getX() + ", " + getY());
        super.draw(batch);
    }


    public void update(float delta) {
        if (!dragging) {
            dragPosition.set(base);
        }
    }
    public void dispose() {
        if (body != null && body.getWorld() != null) {
            world.destroyBody(body);
        }
        if (trajectoryRenderer!=null){
            trajectoryRenderer.dispose();
        }
    }

    public void startDrag(float x, float y) {
        dragging = true;
        dragPosition.set(x, y);
    }

    public void updateDrag(float x, float y, ShapeRenderer shapeRenderer) {
        if (dragging) {
            dragPosition.set(x, y);
            //Gdx.app.log("Slingshot", "Dragging at: " + x + ", " + y);
        }
    }

    public void release() {
        dragging = false;
    }

    public Vector2 launchVelocity() {
        Vector2 direction = top.cpy().sub(dragPosition);
        direction.y *= 1.5f;
        return direction.scl(1);
    }

    public void renderTrajectory(){
        if (dragging) {
            Vector2 velocity = launchVelocity();
            Gdx.app.log("trajectory", "Start Position: (" + (top.x - 270) + ", " + (top.y - 25) + ")");

            trajectoryRenderer.renderTrajectory(top.x - 270, top.y - 25, velocity, -9.8f, 0.1f, 5f);
        }
    }
}
