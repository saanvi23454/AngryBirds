<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="elementWood025" tilewidth="64" tileheight="64" spacing="2" margin="1" tilecount="6" columns="2">
 <image source="elementWood025.png" width="140" height="220"/>
</tileset>
