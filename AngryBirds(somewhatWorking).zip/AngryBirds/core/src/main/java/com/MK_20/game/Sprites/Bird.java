package com.MK_20.game.Sprites;

import com.MK_20.game.AngryBirds;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Ellipse;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;

public abstract class Bird extends InteractiveTileObject{

    public float health; // Serializable fields

//    public Bird(){}

    public Bird(World world, TiledMap tiledmap, Ellipse bounds, String s) {
        super(world, tiledmap, bounds);
        this.health = 100;

        this.sprite = new Sprite(new Texture(s));
        // Set the size of the sprite to match the physical body
        sprite.setSize(bounds.width / AngryBirds.PPM, bounds.height / AngryBirds.PPM);

        // Set the position of the sprite to match the physics body
        sprite.setPosition(bounds.x / AngryBirds.PPM, bounds.y / AngryBirds.PPM);
        BodyDef bodyDef = new BodyDef();
        FixtureDef fixtureDef = new FixtureDef();
        PolygonShape shape = new PolygonShape();

        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set((bounds.x+(bounds.width/2)) / AngryBirds.PPM, (bounds.y+(bounds.height/2)) / AngryBirds.PPM);

        body = world.createBody(bodyDef);
        shape.setAsBox(bounds.width/2 / AngryBirds.PPM, bounds.height/2 / AngryBirds.PPM);
        fixtureDef.shape = shape;
        body.createFixture(fixtureDef);
    }

//    @Override
//    public void write(Json json) {
//        // Save serializable fields
//        json.writeValue("x", x);
//        json.writeValue("y", y);
//        json.writeValue("width", width);
//        json.writeValue("height", height);
//        json.writeValue("radius", radius);
//        json.writeValue("texturePath", texturePath);
//        json.writeValue("health", health);
//    }
//
//    @Override
//    public void read(Json json, JsonValue jsonData) {
//        try {
//            // Load serializable fields
//            x = json.readValue("x", Float.class, jsonData);
//            y = json.readValue("y", Float.class, jsonData);
//            width = json.readValue("width", Float.class, jsonData);
//            height = json.readValue("height", Float.class, jsonData);
//            radius = json.readValue("radius", Float.class, jsonData);
//            texturePath = json.readValue("texturePath", String.class, jsonData);
//            health = json.readValue("health", Float.class, jsonData);
//        }
//        catch (Exception e) {
//            System.out.println("Error deserializing bird: " + e.getMessage());
//        }
//    }
}