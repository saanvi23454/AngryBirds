package com.MK_20.game.Sprites;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTile;
import com.badlogic.gdx.math.Ellipse;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.World;

public abstract class InteractiveTileObject {
    protected World world;
    protected TiledMap tiledMap;
    protected TiledMapTile tile;
    protected Rectangle bounds;
    protected Ellipse eBounds;
    public Body body;
    protected Sprite sprite;

    public InteractiveTileObject(World world, TiledMap tiledMap, Rectangle bounds) {
        this.world = world;
        this.tiledMap = tiledMap;
        this.bounds = bounds;
        this.eBounds=null;
    }

    public InteractiveTileObject(World world, TiledMap tiledMap, Ellipse bounds) {
        this.world = world;
        this.tiledMap = tiledMap;
        this.eBounds = bounds;
        this.bounds=null;
    }

    public void update() {
        // Update the sprite's position based on the body's position
        if (body!=null){
            sprite.setPosition(body.getPosition().x-sprite.getWidth()/2, body.getPosition().y-sprite.getHeight()/2);
        }
    }

    public void draw(SpriteBatch batch) {
        sprite.draw(batch);
    }
}
