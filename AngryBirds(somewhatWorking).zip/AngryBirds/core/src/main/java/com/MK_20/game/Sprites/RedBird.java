package com.MK_20.game.Sprites;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Ellipse;
import com.badlogic.gdx.physics.box2d.*;

public class RedBird extends Bird {

//    public RedBird(){}

    public RedBird(World world, TiledMap tiledMap, Ellipse ellipse) {
        super(world,tiledMap,ellipse, "redBird.png");
    }
}
