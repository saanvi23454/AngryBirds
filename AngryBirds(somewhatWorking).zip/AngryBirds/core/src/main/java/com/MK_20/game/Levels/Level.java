package com.MK_20.game.Levels;

import com.MK_20.game.AngryBirds;
import com.MK_20.game.Sprites.Bird;
import com.MK_20.game.Sprites.Pig;
import com.MK_20.game.Sprites.Slingshot;
import com.MK_20.game.Sprites.Wood;
import com.MK_20.game.Tools.LevelCreator;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.utils.Timer;

import java.util.ArrayList;

public class Level {
    public Bird currentBird;
    public ArrayList<Bird> thrownBirds;
    public LevelCreator levelCreator;

    public Level(LevelCreator l) {
        levelCreator = l;
        thrownBirds = new ArrayList<>();
        currentBird=l.birds.get(0);
    }

    public void update(float delta){
        for (int i=0; i<levelCreator.birds.size(); i++){
            levelCreator.birds.get(i).update();
        }
        for (int i=0; i<thrownBirds.size(); i++){
            thrownBirds.get(i).update();
        }
        for (int i=0; i<levelCreator.woods.size(); i++){
            levelCreator.woods.get(i).update();
        }
        for (int i=0; i<levelCreator.pigs.size(); i++){
            levelCreator.pigs.get(i).update();
        }
        if (levelCreator.pigs.isEmpty()){
            Timer.schedule(new Timer.Task() {
                @Override
                public void run() {
                    // change to win screen after 4 sec
                    AngryBirds.game.setScreen(AngryBirds.game.won);
                }
            }, 2.0f);
        }
        if (levelCreator.birds.isEmpty()){
            //end button.
            AngryBirds.game.setScreen(AngryBirds.game.failed);
        }
    }

    public void releaseBird(Vector2 velocity, Slingshot slingshot) {
        if (currentBird != null) {
            Gdx.app.log("Release", "Bird velocity: " + velocity);
            currentBird.body.setType(BodyDef.BodyType.DynamicBody);
            currentBird.body.setLinearVelocity(velocity);
            currentBird.body.setLinearVelocity(currentBird.body.getLinearVelocity().scl(5));
            levelCreator.birds.remove(currentBird);
            thrownBirds.add(currentBird);
            currentBird = null; //modify to make it the next bird
            if (!levelCreator.birds.isEmpty()) {
                setBird(slingshot);
            }
        }
    }

    public void setBird(Slingshot slingshot){

        this.currentBird = levelCreator.birds.get(0);

        // Update bird's physics body position
        this.currentBird.body.setTransform(levelCreator.slingshot.top.x, levelCreator.slingshot.top.y, 0);

        // Set bird's body type to static (so it doesn't fall)
        this.currentBird.body.setType(BodyDef.BodyType.StaticBody);
    }

    public void drawAll(SpriteBatch batch){
        batch.begin();
        for (int i=0; i<levelCreator.pigs.size(); i++){
            levelCreator.pigs.get(i).draw(batch);
        }
        for (int i=0; i<levelCreator.birds.size(); i++){
            levelCreator.birds.get(i).draw(batch);
        }
        for (int i=0; i<thrownBirds.size(); i++){
            thrownBirds.get(i).draw(batch);
        }
        for (int i=0; i<levelCreator.woods.size(); i++){
            levelCreator.woods.get(i).draw(batch);
        }
        for (int i=0; i<levelCreator.glass.size(); i++){}
        batch.end();
    }
}
