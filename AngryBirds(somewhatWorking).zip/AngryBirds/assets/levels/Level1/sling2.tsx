<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="sling2" tilewidth="64" tileheight="64" tilecount="6" columns="2">
 <image source="../../sling2.png" width="152" height="248"/>
</tileset>
