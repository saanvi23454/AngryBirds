<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="sling" tilewidth="64" tileheight="64" tilecount="360" columns="15">
 <image source="../../sling.png" width="969" height="1580"/>
</tileset>
